import matplotlib.pyplot as plt
import rcsv

import ger_grafico_linhas
import ger_histograma
import ger_grafico_dispersao

def menu():
    print('=============MENU===============')
    print('  ESCOLHA UMA DAS TRÊS OPÇÕES   ')
    print('1- Gráfico de linhas')
    print('2- Histograma')
    print('3- Dispersão (Scatterplot)')
    print('4- Sair do programa')
    print('===============================')
    escolha = int(input('Digite a opção (1 a 4):'))

    if escolha == 1:
        ger_grafico_linhas.gerar_grafico_linhas()
    elif escolha == 2:
        ger_histograma.gerar_histograma()
    elif escolha == 3:
        ger_grafico_dispersao.gerar_grafico_dispersao()
    elif escolha == 4:
        return
    else:
        print("Opção inválida.")

    menu()

if __name__ == "__main__":
    menu()
