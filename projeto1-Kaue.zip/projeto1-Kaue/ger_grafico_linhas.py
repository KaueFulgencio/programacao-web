import matplotlib.pyplot as plt
import read_arq_csv

def gerar_grafico_linhas():
    nome_arquivo_entrada = "dados/dados-com-titulo.csv"
    nome_arquivo_saida = "grafico-linhas.png"
    titulo_grafico = "Gráfico de linhas"
    titulo_eixo_x = "Tempo (s)"
    titulo_eixo_y = "Altura (m)"
    
    dados = read_arq_csv(nome_arquivo_entrada)
    dados_eixo_x = dados[0]
    dados_eixo_y = dados[1]
    rotulos_dados = dados[2]

    figura = plt.figure()
    ax = figura.add_axes([0, 0, 1, 1])

    for i in range(len(dados)):
        ax.plot(dados_eixo_x[i], dados_eixo_y[i])

    ax.set_title(titulo_grafico)
    ax.set_xlabel(titulo_eixo_x)
    ax.set_ylabel(titulo_eixo_y)

    if rotulos_dados:
        for i in range(len(dados)):
            ax.annotate(rotulos_dados[i], (dados_eixo_x[i][0], dados_eixo_y[i][0]))

    plt.savefig(nome_arquivo_saida)
    plt.show()
