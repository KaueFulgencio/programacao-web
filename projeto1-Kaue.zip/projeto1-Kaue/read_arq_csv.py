import csv

def read_arq_csv(nome_arquivo):
    with open(nome_arquivo, 'r') as arquivo_csv:
        leitor_csv = csv.reader(arquivo_csv)
        dados = [row for row in leitor_csv]
    
    dados = [[float(valor) for valor in linha] for linha in dados]
    
    return dados
