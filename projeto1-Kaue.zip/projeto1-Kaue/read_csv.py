import csv

def read_csv(fname):
    dados = []
    with open(fname) as File:
        read_l = csv.reader(File)
        for l in read_l:
            if(not dados):
                for col in l:
                    dados.append([])
            for col in range(0,len(l)):
                dados[col].append(l[col])
    return dados
